"""
config.py — Foundation Harvester Configuration

Central place for all settings: scan locations, exclusion rules,
hashing limits, and database location.

Edit this file to change what gets scanned and how.
No other module should hardcode paths or settings — they all
import from here.
"""

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------

# Where the SQLite registry lives. Defaults to a file next to this script.
DB_PATH = os.environ.get(
    "HARVESTER_DB_PATH",
    str(Path(__file__).parent / "harvester_registry.db")
)

# ---------------------------------------------------------------------------
# Scan roots
# ---------------------------------------------------------------------------
#
# These are the storage locations the scanner will walk recursively.
# Termux on Android typically exposes shared storage at:
#   /storage/emulated/0/   (after `termux-setup-storage`)
# and Termux's own home at:
#   /data/data/com.termux/files/home  (== $HOME)
#
# Paths that don't exist on this device are silently skipped — you don't
# need to edit this list per-device, just make sure termux-setup-storage
# has been run so /storage/emulated/0 is accessible.

def _shared_storage_root() -> str:
    """Best-effort guess at the shared storage root on Android/Termux."""
    candidates = [
        "/storage/emulated/0",
        os.path.expanduser("~/storage/shared"),  # termux-setup-storage symlink
    ]
    for c in candidates:
        if os.path.isdir(c):
            return c
    return ""


_SHARED = _shared_storage_root()

SCAN_ROOTS = [
    p for p in [
        os.path.join(_SHARED, "Download") if _SHARED else "",
        os.path.join(_SHARED, "Documents") if _SHARED else "",
        os.path.join(_SHARED, "Pictures") if _SHARED else "",
        os.path.join(_SHARED, "Movies") if _SHARED else "",
        os.path.join(_SHARED, "Music") if _SHARED else "",
        os.path.join(_SHARED, "DCIM") if _SHARED else "",
        os.path.join(_SHARED, "Android", "media") if _SHARED else "",
        os.path.expanduser("~"),  # Termux home (includes git repos, projects)
    ]
    if p and os.path.isdir(p)
]

# You can also add custom paths manually here, e.g.:
# SCAN_ROOTS.append("/storage/emulated/0/MyProjects")

# ---------------------------------------------------------------------------
# Exclusions
# ---------------------------------------------------------------------------

# Directory names to never descend into, anywhere in the tree.
EXCLUDED_DIR_NAMES = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".cache",
    "Android",  # avoid most of /Android except /Android/media which is added explicitly
    "Trash",
    ".thumbnails",
    "$RECYCLE.BIN",
}

# Full directory paths to never descend into (absolute paths).
EXCLUDED_DIR_PATHS = set()

# File extensions to skip entirely (lowercase, with dot).
EXCLUDED_EXTENSIONS = {
    ".tmp",
    ".lock",
    ".part",
}

# ---------------------------------------------------------------------------
# Hashing limits
# ---------------------------------------------------------------------------

# Files larger than this will still be recorded, but SHA-256 hashing will be
# skipped (hashing multi-GB video files on a phone is slow and usually not
# useful for duplicate detection anyway). Set to None to always hash.
MAX_HASH_SIZE_BYTES = 500 * 1024 * 1024  # 500 MB

# Chunk size used when reading files for hashing (memory efficiency).
HASH_CHUNK_SIZE = 65536  # 64 KB

# ---------------------------------------------------------------------------
# Misc
# ---------------------------------------------------------------------------

# How often (in files scanned) to print progress to the console.
PROGRESS_INTERVAL = 200

# Follow symlinks while walking directories? Generally False to avoid
# infinite loops and double-counting.
FOLLOW_SYMLINKS = False
