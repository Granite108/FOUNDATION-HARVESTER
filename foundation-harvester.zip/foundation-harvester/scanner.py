"""
scanner.py — Foundation Harvester Asset Discovery (Phase 1)

Recursively walks every configured scan root, recording metadata for
every file found. This module is READ-ONLY: it never moves, renames,
deletes, or modifies any file or directory it encounters. It only
reads file metadata and (for hashing) file bytes.

The scanner doesn't talk to SQLite directly — it yields plain dicts
that main.py hands to registry.upsert_asset(). This keeps scanning
logic independent of storage, so it's easy to test or swap later.
"""

import os
import hashlib
import mimetypes
from datetime import datetime, timezone
from pathlib import Path

import config


def _iso(timestamp: float) -> str:
    """Convert a Unix timestamp to an ISO 8601 UTC string."""
    try:
        return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
    except (OSError, OverflowError, ValueError):
        return ""


def _hash_file(path: str, size_bytes: int) -> str:
    """
    Compute SHA-256 of a file's contents. Returns None if the file is
    larger than the configured limit, unreadable, or vanished mid-scan
    (e.g. a temp file deleted by another process).
    """
    if config.MAX_HASH_SIZE_BYTES is not None and size_bytes > config.MAX_HASH_SIZE_BYTES:
        return None

    hasher = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            while True:
                chunk = f.read(config.HASH_CHUNK_SIZE)
                if not chunk:
                    break
                hasher.update(chunk)
        return hasher.hexdigest()
    except (IOError, OSError, PermissionError):
        return None


def _guess_project_folder(path: str, roots: list):
    """
    Best-effort guess at which "project" a file belongs to.

    Heuristic: walk up from the file's immediate parent looking for a
    directory containing a recognizable project marker (.git,
    package.json, requirements.txt, pyproject.toml, README*). The search
    stops at the scan root — it never returns a bare scan root (Download,
    Documents, Pictures, etc.) as a "project," since that's just noise.

    Returns None if no project marker is found between the file and its
    scan root — the file is just a loose file, not part of a project.
    """
    markers = {".git", "package.json", "requirements.txt", "pyproject.toml", "README.md", "README"}

    p = Path(path).resolve()
    parent = p.parent

    # Find which root this file is under, if any.
    matching_root = None
    for root in roots:
        try:
            parent.relative_to(Path(root).resolve())
            matching_root = Path(root).resolve()
            break
        except ValueError:
            continue

    current = parent
    while True:
        # Never treat the scan root itself (or above it) as a project folder.
        if matching_root is not None and current == matching_root:
            return None

        try:
            if any((current / m).exists() for m in markers):
                return str(current)
        except (OSError, PermissionError):
            pass

        if current.parent == current:  # reached filesystem root, no root matched
            return None

        current = current.parent


def _safe_lstat(path: str):
    """Stat a path without following symlinks, returning None on failure."""
    try:
        return os.lstat(path)
    except (OSError, PermissionError):
        return None


def scan_roots(roots: list = None, hash_files: bool = True, progress_callback=None):
    """
    Walk every root in `roots` (defaults to config.SCAN_ROOTS) and yield
    one dict per discovered file. Directories matching EXCLUDED_DIR_NAMES
    or EXCLUDED_DIR_PATHS are pruned and never descended into.

    `progress_callback`, if given, is called as progress_callback(count, current_path)
    every config.PROGRESS_INTERVAL files — useful for a CLI progress line.

    Yields dicts shaped for registry.upsert_asset():
        path, filename, extension, mime_type, size_bytes,
        created_time, modified_time, sha256, parent_folder, project_folder

    Also yields a final summary dict with key "__summary__" containing
    counts of files found and errors encountered, so callers don't need
    a second pass just to get totals.
    """
    roots = roots or config.SCAN_ROOTS
    excluded_names = config.EXCLUDED_DIR_NAMES
    excluded_paths = config.EXCLUDED_DIR_PATHS
    excluded_exts = config.EXCLUDED_EXTENSIONS

    count = 0
    errors = 0

    for root in roots:
        if not os.path.isdir(root):
            continue

        for dirpath, dirnames, filenames in os.walk(root, followlinks=config.FOLLOW_SYMLINKS):
            # Prune excluded directories in-place so os.walk doesn't descend into them.
            dirnames[:] = [
                d for d in dirnames
                if d not in excluded_names
                and os.path.join(dirpath, d) not in excluded_paths
            ]

            for fname in filenames:
                full_path = os.path.join(dirpath, fname)
                ext = os.path.splitext(fname)[1].lower()

                if ext in excluded_exts:
                    continue

                stat_result = _safe_lstat(full_path)
                if stat_result is None:
                    errors += 1
                    continue

                # Skip non-regular files (sockets, devices, broken symlinks, etc.)
                if not os.path.isfile(full_path):
                    continue

                size_bytes = stat_result.st_size
                mime_type, _ = mimetypes.guess_type(full_path)
                sha256 = _hash_file(full_path, size_bytes) if hash_files else None

                asset = {
                    "path": full_path,
                    "filename": fname,
                    "extension": ext,
                    "mime_type": mime_type or "",
                    "size_bytes": size_bytes,
                    "created_time": _iso(stat_result.st_ctime),
                    "modified_time": _iso(stat_result.st_mtime),
                    "sha256": sha256,
                    "parent_folder": dirpath,
                    "project_folder": _guess_project_folder(full_path, roots),
                }

                count += 1
                if progress_callback and count % config.PROGRESS_INTERVAL == 0:
                    progress_callback(count, full_path)

                yield asset

    yield {"__summary__": True, "files_found": count, "errors": errors}
