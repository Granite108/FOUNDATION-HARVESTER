"""
registry.py — Foundation Harvester Registry (SQLite layer)

This module owns the database. Every read or write to the asset
registry goes through here — no other module should touch SQLite
directly. That keeps the schema in one place and makes it safe to
change storage backends later without breaking the rest of the app.

Schema overview
----------------
assets table — one row per discovered file.
    id              INTEGER PRIMARY KEY
    path            TEXT UNIQUE NOT NULL   -- absolute path
    filename        TEXT NOT NULL
    extension       TEXT                   -- lowercase, with dot, may be ''
    mime_type       TEXT
    size_bytes      INTEGER
    created_time    TEXT                   -- ISO 8601
    modified_time   TEXT                   -- ISO 8601
    sha256          TEXT                   -- NULL if skipped (too large/unreadable)
    parent_folder   TEXT                   -- immediate containing directory
    project_folder  TEXT                   -- best-guess top-level project root
    scan_id         INTEGER                -- which scan run discovered/confirmed this
    first_seen      TEXT                   -- ISO 8601, first time this path was seen
    last_seen       TEXT                   -- ISO 8601, most recent scan that saw it
    is_missing      INTEGER DEFAULT 0      -- 1 if not found in most recent scan

scans table — one row per scan run, for history/auditing.
    id              INTEGER PRIMARY KEY
    started_at      TEXT
    finished_at     TEXT
    roots_scanned   TEXT                   -- JSON list of roots
    files_found     INTEGER
    errors          INTEGER
"""

import sqlite3
import json
from contextlib import contextmanager
from datetime import datetime, timezone

import config


SCHEMA = """
CREATE TABLE IF NOT EXISTS assets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    path            TEXT UNIQUE NOT NULL,
    filename        TEXT NOT NULL,
    extension       TEXT,
    mime_type       TEXT,
    size_bytes      INTEGER,
    created_time    TEXT,
    modified_time   TEXT,
    sha256          TEXT,
    parent_folder   TEXT,
    project_folder  TEXT,
    scan_id         INTEGER,
    first_seen      TEXT,
    last_seen       TEXT,
    is_missing      INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_assets_filename ON assets(filename);
CREATE INDEX IF NOT EXISTS idx_assets_extension ON assets(extension);
CREATE INDEX IF NOT EXISTS idx_assets_sha256 ON assets(sha256);
CREATE INDEX IF NOT EXISTS idx_assets_project ON assets(project_folder);
CREATE INDEX IF NOT EXISTS idx_assets_parent ON assets(parent_folder);
CREATE INDEX IF NOT EXISTS idx_assets_missing ON assets(is_missing);

CREATE TABLE IF NOT EXISTS scans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    started_at      TEXT,
    finished_at     TEXT,
    roots_scanned   TEXT,
    files_found     INTEGER,
    errors          INTEGER
);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


@contextmanager
def get_connection(db_path: str = None):
    """Context-managed SQLite connection with row factory set for dict-like access."""
    path = db_path or config.DB_PATH
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db(db_path: str = None) -> None:
    """Create tables/indexes if they don't already exist. Safe to call every run."""
    with get_connection(db_path) as conn:
        conn.executescript(SCHEMA)


# ---------------------------------------------------------------------------
# Scan run tracking
# ---------------------------------------------------------------------------

def start_scan(roots: list, db_path: str = None) -> int:
    """Record the start of a scan run. Returns the new scan_id."""
    with get_connection(db_path) as conn:
        cur = conn.execute(
            "INSERT INTO scans (started_at, roots_scanned, files_found, errors) "
            "VALUES (?, ?, 0, 0)",
            (_now(), json.dumps(roots)),
        )
        return cur.lastrowid


def finish_scan(scan_id: int, files_found: int, errors: int, db_path: str = None) -> None:
    """Record completion stats for a scan run."""
    with get_connection(db_path) as conn:
        conn.execute(
            "UPDATE scans SET finished_at = ?, files_found = ?, errors = ? WHERE id = ?",
            (_now(), files_found, errors, scan_id),
        )


# ---------------------------------------------------------------------------
# Asset upsert
# ---------------------------------------------------------------------------

def upsert_asset(asset: dict, scan_id: int, db_path: str = None) -> None:
    """
    Insert a new asset record, or update an existing one (matched by path).

    `asset` is expected to be a dict with keys matching the columns:
    path, filename, extension, mime_type, size_bytes, created_time,
    modified_time, sha256, parent_folder, project_folder.
    """
    now = _now()
    with get_connection(db_path) as conn:
        existing = conn.execute(
            "SELECT id, first_seen FROM assets WHERE path = ?", (asset["path"],)
        ).fetchone()

        if existing:
            conn.execute(
                """
                UPDATE assets SET
                    filename = ?, extension = ?, mime_type = ?, size_bytes = ?,
                    created_time = ?, modified_time = ?, sha256 = ?,
                    parent_folder = ?, project_folder = ?, scan_id = ?,
                    last_seen = ?, is_missing = 0
                WHERE path = ?
                """,
                (
                    asset["filename"], asset["extension"], asset["mime_type"],
                    asset["size_bytes"], asset["created_time"], asset["modified_time"],
                    asset["sha256"], asset["parent_folder"], asset["project_folder"],
                    scan_id, now, asset["path"],
                ),
            )
        else:
            conn.execute(
                """
                INSERT INTO assets (
                    path, filename, extension, mime_type, size_bytes,
                    created_time, modified_time, sha256, parent_folder,
                    project_folder, scan_id, first_seen, last_seen, is_missing
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    asset["path"], asset["filename"], asset["extension"],
                    asset["mime_type"], asset["size_bytes"], asset["created_time"],
                    asset["modified_time"], asset["sha256"], asset["parent_folder"],
                    asset["project_folder"], scan_id, now, now,
                ),
            )


def mark_missing_not_in_scan(scan_id: int, db_path: str = None) -> int:
    """
    After a scan completes, mark any asset whose scan_id is older than the
    current one as missing (it existed before but wasn't found this time).
    Returns the count of newly-missing assets.
    """
    with get_connection(db_path) as conn:
        cur = conn.execute(
            "UPDATE assets SET is_missing = 1 WHERE scan_id != ? AND is_missing = 0",
            (scan_id,),
        )
        return cur.rowcount


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------

def search(
    filename: str = None,
    extension: str = None,
    project_folder: str = None,
    folder: str = None,
    keyword: str = None,
    duplicates_only: bool = False,
    include_missing: bool = False,
    order_by: str = "modified_time DESC",
    limit: int = 200,
    db_path: str = None,
) -> list:
    """
    Flexible search over the assets table. All filters are optional and
    combine with AND. `keyword` does a loose match against filename + path.
    """
    clauses = []
    params = []

    if filename:
        clauses.append("filename LIKE ?")
        params.append(f"%{filename}%")
    if extension:
        ext = extension if extension.startswith(".") else f".{extension}"
        clauses.append("extension = ?")
        params.append(ext.lower())
    if project_folder:
        clauses.append("project_folder LIKE ?")
        params.append(f"%{project_folder}%")
    if folder:
        clauses.append("parent_folder LIKE ?")
        params.append(f"%{folder}%")
    if keyword:
        clauses.append("(filename LIKE ? OR path LIKE ?)")
        params.append(f"%{keyword}%")
        params.append(f"%{keyword}%")
    if not include_missing:
        clauses.append("is_missing = 0")

    where = f"WHERE {' AND '.join(clauses)}" if clauses else ""

    sql = f"SELECT * FROM assets {where} ORDER BY {order_by} LIMIT ?"
    params.append(limit)

    with get_connection(db_path) as conn:
        rows = conn.execute(sql, params).fetchall()
        results = [dict(r) for r in rows]

    if duplicates_only:
        results = _filter_to_duplicates(results, db_path)

    return results


def _filter_to_duplicates(rows: list, db_path: str = None) -> list:
    """Given a list of asset rows, keep only those whose sha256 appears more than once globally."""
    hashes = [r["sha256"] for r in rows if r.get("sha256")]
    if not hashes:
        return []
    dup_hashes = find_duplicate_hashes(db_path)
    return [r for r in rows if r.get("sha256") in dup_hashes]


def find_duplicate_hashes(db_path: str = None) -> set:
    """Return the set of sha256 values that occur on more than one non-missing asset."""
    with get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT sha256 FROM assets
            WHERE sha256 IS NOT NULL AND is_missing = 0
            GROUP BY sha256
            HAVING COUNT(*) > 1
            """
        ).fetchall()
    return {r["sha256"] for r in rows}


def get_duplicate_groups(db_path: str = None) -> dict:
    """Return {sha256: [asset_dict, ...]} for every hash with 2+ live files."""
    dup_hashes = find_duplicate_hashes(db_path)
    if not dup_hashes:
        return {}
    with get_connection(db_path) as conn:
        placeholders = ",".join("?" for _ in dup_hashes)
        rows = conn.execute(
            f"SELECT * FROM assets WHERE sha256 IN ({placeholders}) AND is_missing = 0",
            list(dup_hashes),
        ).fetchall()
    groups = {}
    for r in rows:
        d = dict(r)
        groups.setdefault(d["sha256"], []).append(d)
    return groups


def get_stats(db_path: str = None) -> dict:
    """Dashboard summary: totals, duplicate count, last scan time, storage usage."""
    with get_connection(db_path) as conn:
        total_assets = conn.execute(
            "SELECT COUNT(*) c FROM assets WHERE is_missing = 0"
        ).fetchone()["c"]

        total_size = conn.execute(
            "SELECT COALESCE(SUM(size_bytes), 0) s FROM assets WHERE is_missing = 0"
        ).fetchone()["s"]

        project_count = conn.execute(
            "SELECT COUNT(DISTINCT project_folder) c FROM assets "
            "WHERE is_missing = 0 AND project_folder IS NOT NULL"
        ).fetchone()["c"]

        missing_count = conn.execute(
            "SELECT COUNT(*) c FROM assets WHERE is_missing = 1"
        ).fetchone()["c"]

        last_scan = conn.execute(
            "SELECT * FROM scans ORDER BY id DESC LIMIT 1"
        ).fetchone()

        top_folders = conn.execute(
            """
            SELECT parent_folder, COUNT(*) cnt, SUM(size_bytes) total_size
            FROM assets WHERE is_missing = 0 AND parent_folder IS NOT NULL
            GROUP BY parent_folder ORDER BY total_size DESC LIMIT 10
            """
        ).fetchall()

    dup_hashes = find_duplicate_hashes(db_path)

    return {
        "total_assets": total_assets,
        "total_size_bytes": total_size,
        "project_count": project_count,
        "duplicate_group_count": len(dup_hashes),
        "missing_count": missing_count,
        "last_scan": dict(last_scan) if last_scan else None,
        "top_folders": [dict(f) for f in top_folders],
    }


def get_all_projects(db_path: str = None) -> list:
    """List distinct project folders with file counts."""
    with get_connection(db_path) as conn:
        rows = conn.execute(
            """
            SELECT project_folder, COUNT(*) file_count, SUM(size_bytes) total_size
            FROM assets
            WHERE is_missing = 0 AND project_folder IS NOT NULL
            GROUP BY project_folder
            ORDER BY file_count DESC
            """
        ).fetchall()
    return [dict(r) for r in rows]
